
#ifndef CNC_h
#define CNC_h

#include "Arduino.h"


class CNC
{
  public:
    CNC();
    void bagr();
  private:
};

#endif

